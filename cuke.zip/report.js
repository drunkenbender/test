$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("/usr/local/features/fund/fund_loan.feature");
formatter.feature({
  "line": 1,
  "name": "Fund Loan",
  "description": "\nFund a loan.",
  "id": "fund-loan",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 6,
  "name": "Fund a whole loan",
  "description": "",
  "id": "fund-loan;fund-a-whole-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@fund-whole-loan"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Underwriter has successfully underwritten the loan as a whole loan",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 9,
      "value": "#When placeholder2"
    },
    {
      "line": 10,
      "value": "#Then placeholder2"
    }
  ],
  "line": 11,
  "name": "The investor buys the whole loan",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "The underwriter successfully funds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Loan engine should show a loan part assigned to the investor for the loan",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "Investor portal should show that the investor holds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Loan engine should show that the amoritization schedule has been created",
  "keyword": "And "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 63448575542,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_whole_loan()"
});
formatter.result({
  "duration": 305098390657,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.The_investor_funds_the_whole_loan()"
});
formatter.result({
  "duration": 180007556187,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.The_underwriter_successfully_funds_the_whole_loan()"
});
formatter.result({
  "duration": 20340803318,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Loan_engine_should_show_a_loan_part_assigned_to_the_investor_for_whole_loan()"
});
formatter.result({
  "duration": 737500568977,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.The_investor_holds_the_loan()"
});
formatter.result({
  "duration": 77171193893,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.The_amoritization_schedule_has_been_created()"
});
formatter.result({
  "duration": 5707521065,
  "status": "passed"
});
formatter.after({
  "duration": 60000479312,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Fund a kls loan",
  "description": "",
  "id": "fund-loan;fund-a-kls-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 17,
      "name": "@fund-kls-loan"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Underwriter has successfully underwritten the loan as a kls loan",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 21,
      "value": "#Given placeholder2"
    },
    {
      "line": 22,
      "value": "#When placeholder2"
    }
  ],
  "line": 23,
  "name": "Investor api responses for the kls loan match the kls loan application data",
  "keyword": "Then "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 58131250859,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_kls_loan()"
});
formatter.result({
  "duration": 314555437948,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.Investor_api_responses_for_the_loan_match_the_kls_loan_application_data()"
});
formatter.result({
  "duration": 7936751094,
  "status": "passed"
});
formatter.after({
  "duration": 60000364049,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Fund a fractional loan",
  "description": "",
  "id": "fund-loan;fund-a-fractional-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@fund-fractional-loan"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "Underwriter has successfully underwritten the loan as a fractional loan",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "The underwriter successfully funds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "An investor bids on the fractional loan",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "Another investor bids on the fractional loan and is approved",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Loan engine should show a loan part assigned to the investor for the loan",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "Investor portal should show the approved investor holds the fractional loan",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Loan engine should show that the amoritization schedule has been created",
  "keyword": "And "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 59250450309,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_fractional_loan()"
});
formatter.result({
  "duration": 294245024393,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.The_underwriter_successfully_funds_the_whole_loan()"
});
formatter.result({
  "duration": 20280097943,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.An_investor_bids_on_the_fractional_loan()"
});
formatter.result({
  "duration": 152163312253,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.Another_investor_bids_on_the_fractional_loan_and_is_approved()"
});
formatter.result({
  "duration": 87166330614,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Loan_engine_should_show_a_loan_part_assigned_to_the_investor_for_whole_loan()"
});
formatter.result({
  "duration": 245231152881,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.Investor_portal_should_show_the_approved_investor_holds_the_fractional_loan()"
});
formatter.result({
  "duration": 69926788311,
  "status": "passed"
});
formatter.match({
  "location": "InvestorFundingStep.The_amoritization_schedule_has_been_created()"
});
formatter.result({
  "duration": 6307410971,
  "status": "passed"
});
formatter.after({
  "duration": 60000328286,
  "status": "passed"
});
}); "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.The_underwriter_successfully_funds_the_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.Loan_engine_should_show_a_loan_part_assigned_to_the_investor_for_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.The_investor_holds_the_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.The_amoritization_schedule_has_been_created()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 60001056785,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Fund a kls loan",
  "description": "",
  "id": "fund-loan;fund-a-kls-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 17,
      "name": "@fund-kls-loan"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Underwriter has successfully underwritten the loan as a kls loan",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 21,
      "value": "#Given placeholder2"
    },
    {
      "line": 22,
      "value": "#When placeholder2"
    }
  ],
  "line": 23,
  "name": "Investor api responses for the kls loan match the kls loan application data",
  "keyword": "Then "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 2928260,
  "error_message": "java.lang.AssertionError: Previous scenario failed so this scenario will be marked as failed also.\n\tat org.junit.Assert.fail(Assert.java:88)\n\tat com.fundingcircle.qa.steps.BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input(BorrowerApplicationStep.java:112)\n\tat ✽.Given Borrower has successfully originated a loan using random loan application input(/usr/local/features/fund/fund_loan.feature:19)\n",
  "status": "failed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_kls_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.Investor_api_responses_for_the_loan_match_the_kls_loan_application_data()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 60000490038,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Fund a fractional loan",
  "description": "",
  "id": "fund-loan;fund-a-fractional-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@fund-fractional-loan"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "Underwriter has successfully underwritten the loan as a fractional loan",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "The underwriter successfully funds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "An investor bids on the fractional loan",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "Another investor bids on the fractional loan and is approved",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Loan engine should show a loan part assigned to the investor for the loan",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "Investor portal should show the approved investor holds the fractional loan",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Loan engine should show that the amoritization schedule has been created",
  "keyword": "And "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 493319,
  "error_message": "java.lang.AssertionError: Previous scenario failed so this scenario will be marked as failed also.\n\tat org.junit.Assert.fail(Assert.java:88)\n\tat com.fundingcircle.qa.steps.BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input(BorrowerApplicationStep.java:112)\n\tat ✽.Given Borrower has successfully originated a loan using random loan application input(/usr/local/features/fund/fund_loan.feature:27)\n",
  "status": "failed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_fractional_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.The_underwriter_successfully_funds_the_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.An_investor_bids_on_the_fractional_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.Another_investor_bids_on_the_fractional_loan_and_is_approved()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.Loan_engine_should_show_a_loan_part_assigned_to_the_investor_for_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.Investor_portal_should_show_the_approved_investor_holds_the_fractional_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.The_amoritization_schedule_has_been_created()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 60000511198,
  "status": "passed"
});
});