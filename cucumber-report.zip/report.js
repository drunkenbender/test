$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("/usr/local/features/fund/fund_loan.feature");
formatter.feature({
  "line": 1,
  "name": "Fund Loan",
  "description": "\nFund a loan.",
  "id": "fund-loan",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 6,
  "name": "Fund a whole loan",
  "description": "",
  "id": "fund-loan;fund-a-whole-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@fund-whole-loan"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Borrower has successfully originated a loan using random loan application input",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Underwriter has successfully underwritten the loan as a whole loan",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 9,
      "value": "#When placeholder2"
    },
    {
      "line": 10,
      "value": "#Then placeholder2"
    }
  ],
  "line": 11,
  "name": "The investor buys the whole loan",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "The underwriter successfully funds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Loan engine should show a loan part assigned to the investor for the loan",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "Investor portal should show that the investor holds the loan",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Loan engine should show that the amoritization schedule has been created",
  "keyword": "And "
});
formatter.match({
  "location": "BorrowerApplicationStep.Borrower_has_successfully_originated_a_loan_using_random_loan_application_input()"
});
formatter.result({
  "duration": 43085577860,
  "status": "passed"
});
formatter.match({
  "location": "UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_whole_loan()"
});
formatter.result({
  "duration": 291091603753,
  "error_message": "java.lang.AssertionError:  **Fri Jul 15 20:48:16 GMT 2016** Could not find element with text of Loan successfully listed on url https://admin.fcstaging.us/#/credit/loan_applications/4d03bc19-ca07-4cd3-a383-172ebf975bc1/listing AssertionError: java.lang.AssertionError: \nExpected: not null\n     but: was null\n\tat org.testng.Assert.fail(Assert.java:94)\n\tat com.fundingcircle.qa.util.Util.assertThat(Util.java:335)\n\tat com.fundingcircle.qa.util.SeleniumUtil.findByTextAndAssert(SeleniumUtil.java:219)\n\tat com.fundingcircle.qa.steps.UnderwriteLoanStep.enterListingInputAndSendLoanToMarketPlace(UnderwriteLoanStep.java:733)\n\tat com.fundingcircle.qa.steps.UnderwriteLoanStep.enterListingInputAndSendLoanToWholeMarketplace(UnderwriteLoanStep.java:677)\n\tat com.fundingcircle.qa.steps.UnderwriteLoanStep.I_underwrite_the_loan_as_a_whole_loan(UnderwriteLoanStep.java:132)\n\tat com.fundingcircle.qa.steps.UnderwriteLoanStep.Underwriter_has_successfully_underwritten_the_loan_as_a_whole_loan(UnderwriteLoanStep.java:100)\n\tat ✽.And Underwriter has successfully underwritten the loan as a whole loan(/usr/local/features/fund/fund_loan.feature:8)\n",
  "status": "failed"
});
formatter.match({
  "location": "InvestorFundingStep.The_investor_funds_the_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.The_underwriter_successfully_funds_the_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UnderwriteLoanStep.Loan_engine_should_show_a_loan_part_assigned_to_the_investor_for_whole_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.The_investor_holds_the_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "InvestorFundingStep.The_amoritization_schedule_has_been_created()"
});
formatter.result({
  "status": "skipped"
});
